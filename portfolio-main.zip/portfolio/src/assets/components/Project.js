// import React from 'react'
// import image from "../image/project/image.png"
// import { projectData } from "../json/Project";

// function Project() {
//     return (
//         <>
//             <div className="container text-light py-2 mb-4">
//                 <h2 className="my-5 aboutHeading experience-title">
//                     <span className="highlight">P</span>r<span className="highlight">o</span>j<span className="highlight">ec</span>ts
//                 </h2>

//                 <div className=' d-flex my-5 flex-wrap gap-4 justify-content-around'>
//                     {projectData.map(project => {
//                         return <div className="flip-card">
//                             <div className="flip-card-inner">
//                                 <div className="flip-card-front">
//                                     <img src={project.image ? project.image : image} alt={project.projectName} />
//                                     <p className="px-3 d-flex justify-content-left align-items-center" style={{ height: "50px" }}>
//                                         {project.projectName}
//                                     </p>
//                                 </div>
//                                 <div className="flip-card-back">
//                                     <ul>
//                                         {project.createdDate ? <li className='py-1 mb-1 px-2 bg-dark rounded'><strong className='text-warning'>Created :</strong> {project.createdDate}</li> : ""}
//                                         {project.technologiesUsed ? <li className='py-1 px-2 bg-dark rounded'><strong className='text-warning'>Tech :</strong> {project.technologiesUsed}</li> : ""}
//                                         {project.features.map(feature => {
//                                             return <li>{feature}</li>
//                                         })}
//                                     </ul>
//                                     <div className="flip-card-back-links">
//                                         {project.repositoryLink ? <a href={project.repositoryLink} style={{ padding: "12px" }} target='_blank' rel="noreferrer"><i className="fa fa-github" style={{ fontSize: "2rem" }}></i></a> : ""}
//                                         {project.liveProjectLink ? <a href={project.liveProjectLink} className="p-3" target='_blank' rel="noreferrer"><i className="fa fa-external-link" style={{ fontSize: "1.5rem" }} aria-hidden="true"></i></a> : ""}
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     })}
//                 </div>
//             </div>
//         </>
//     )
// }

// export default Project



// import React from 'react';
// import image from "../image/project/image.png";
// import { projectData } from "../json/Project";

// function Project() {
//     return (
//         <div className="container text-light mb-2 mb-lg-4">
//             <h2 className="project-heading">
//                 <span className="highlight">P</span>r<span className="highlight">o</span>j<span className="highlight">ec</span>ts
//             </h2>

//             <div className='d-flex flex-wrap gap-4 justify-content-around'>
//                 {projectData.map(project => (
//                     <div className="flip-card" key={project.projectName}>
//                         <div className="flip-card-inner">
//                             <div className="flip-card-front">
//                                 <img src={project.image || image} alt={project.projectName} />
//                                 <p className="px-3 d-flex justify-content-left align-items-center" >
//                                     {project.projectName}
//                                 </p>
//                             </div>
//                             <div className="flip-card-back">
//                                 <ul>
//                                     {project.createdDate && (
//                                         <li className='py-1 mb-1 px-2 bg-dark rounded'>
//                                             <strong className='text-warning'>Created :</strong> {project.createdDate}
//                                         </li>
//                                     )}
//                                     {project.technologiesUsed && (
//                                         <li className='py-1 px-2 bg-dark rounded'>
//                                             <strong className='text-warning'>Tech :</strong> {project.technologiesUsed}
//                                         </li>
//                                     )}
//                                     {project.features.map((feature, index) => (
//                                         <li key={index}>{feature}</li>
//                                     ))}
//                                 </ul>
//                                 <div className="flip-card-back-links">
//                                     {project.repositoryLink && (
//                                         <a href={project.repositoryLink} style={{ padding: "12px" }} target='_blank' rel="noreferrer">
//                                             <i className="fa fa-github" style={{ fontSize: "2rem" }}></i>
//                                         </a>
//                                     )}
//                                     {project.liveProjectLink && (
//                                         <a href={project.liveProjectLink} className="p-3" target='_blank' rel="noreferrer">
//                                             <i className="fa fa-external-link" style={{ fontSize: "1.5rem" }} aria-hidden="true"></i>
//                                         </a>
//                                     )}
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                 ))}
//             </div>
//         </div>
//     );
// }

// export default Project;



// import React from 'react';
// import ProjectCard from './project/ProjectCard';

// const project = {
//   image: 'https://via.placeholder.com/300',
//   title: 'Awesome Project',
//   createdDate: '2023-05-01',
//   githubLink: 'https://github.com/your-repo',
//   liveLink: 'https://live-website.com',
//   description: 'This is an amazing project that demonstrates great features and functionality.'
// };

// const Projects = () => {
//   return (
//     <div className="container mt-5">
//       <h2 className="mb-4">My Projects</h2>
//       <ProjectCard project={project} />
//     </div>
//   );
// };

// export default Projects;



import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const projects = [
    {
        image: 'https://via.placeholder.com/300?text=Vacay',
        title: 'Vacay',
        createdDate: '2015',
        description: 'A responsive web application for travel planning that my team developed in ICS 415.',
        tags: ['Javascript', 'Meteor', 'MongoDB', 'GitHub'],
        link: '#'
    },
    // {
    //     image: 'https://via.placeholder.com/300?text=Micromouse',
    //     title: 'Micromouse',
    //     createdDate: '2015',
    //     description: 'My team developed a robotic mouse that won first place in the 2015 UH Micromouse competition.',
    //     tags: ['Robotics', 'Arduino', 'C++', 'GitHub'],
    //     link: '#'
    // },
    // {
    //     image: 'https://via.placeholder.com/300?text=Cotton',
    //     title: 'Cotton',
    //     createdDate: '2014',
    //     description: 'A text adventure game that I developed for ICS 313.',
    //     tags: ['Lisp', 'GitHub'],
    //     link: '#'
    // }
];

const ProjectCard = ({ project }) => {
    return (
        <div className="project-card-container">
            <div className="project-card-left">
                <img src={project.image} className="project-card-image" alt={project.title} />
            </div>
            <div className="project-card-right">
                <h5 className="card-title">{project.title}</h5>
                <p className="card-text">{project.description}</p>
                <p className="card-text">
                    {project.tags.map((tag, index) => (
                        <span key={index} className="badge bg-secondary me-2">{tag}</span>
                    ))}
                </p>
                <p className="card-text">
                    <small className="text-muted">{project.createdDate}</small>
                </p>
                <div className='d-flex gap-4'>
                    <a href={project.link} className="btn btn-outline-info">Read More</a>
                    <a href={project.link} className="btn btn-outline-success ">Live</a>
                </div>
            </div>
        </div>
    );
};

const Projects = () => {
    return (
        <div className="container mt-5">
            <h2 className="project-heading text-light">
                <span className="highlight">P</span>r<span className="highlight">o</span>j<span className="highlight">ec</span>ts
            </h2>
            {projects.map((project, index) => (
                <ProjectCard key={index} project={project} />
            ))}
        </div>
    );
};

export default Projects;
